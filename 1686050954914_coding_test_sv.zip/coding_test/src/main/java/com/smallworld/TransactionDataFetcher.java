package com.smallworld;

import com.smallworld.data.Transaction;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.*;

public class TransactionDataFetcher {

    /**
     * Returns the sum of the amounts of all transactions
     */
    public double getTotalTransactionAmount() {
        Double amount = 0.0;
        JSONParser jp = new JSONParser();
        try{
        Object obj = jp.parse(new FileReader("./transactions.json"));
        JSONObject jsonObject = (JSONObject) obj;
        JSONArray jsonArray = (JSONArray) jsonObject.get("amount");
        for(int i=0;i<jsonArray.size();i++){
            amount+= Double.parseDouble(jsonArray.get(i).toString());
        }
        }catch(Exception ex){
            ex.getMessage();
        }
        return amount;
    }

    /**
     * Returns the sum of the amounts of all transactions sent by the specified client
     */
    public double getTotalTransactionAmountSentBy(String senderFullName) {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the highest transaction amount
     */
    public double getMaxTransactionAmount()  {
        JSONParser jp = new JSONParser();
        Double maxTransactionAmount = 0.0;
        try{
            Object obj = jp.parse(new FileReader("./transactions.json"));
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray jsonArray = (JSONArray) jsonObject.get("amount");
            for(int i=0;i<jsonArray.size();i++){
                Double maxVal =  (Double)jsonArray.get(i);
                if((Double)jsonArray.get(i)>maxVal){
                    maxVal = (Double)jsonArray.get(i);
                }
            }
        }catch (Exception ex){
            ex.getMessage();
        }
        return maxTransactionAmount;
    }

    /**
     * Counts the number of unique clients that sent or received a transaction
     */
    public long countUniqueClients() {
        JSONParser jp = new JSONParser();
        Set uniqueMember = new HashSet();
        Integer numberOfUniqueClient;
        try{
            Object obj = jp.parse(new FileReader("./transactions.json"));
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray jsonArray = (JSONArray) jsonObject.get("beneficiaryFullName");
            var counter = 0;
            for(int i=0;i<jsonArray.size();i++){
                if(jsonArray.get(i).toString().equals(jsonArray.get(counter).toString()))
                {
                    uniqueMember.add(jsonArray.get(i));
                }
                counter++;
            }
        }catch (Exception ex){
            ex.getMessage();
        }
        numberOfUniqueClient = uniqueMember.size();
        return numberOfUniqueClient;
    }

    /**
     * Returns whether a client (sender or beneficiary) has at least one transaction with a compliance
     * issue that has not been solved
     */
    public boolean hasOpenComplianceIssues(String clientFullName) {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns all transactions indexed by beneficiary name
     */
    public Map<String, Transaction> getTransactionsByBeneficiaryName() {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the identifiers of all open compliance issues
     */
    public Set<Integer> getUnsolvedIssueIds() {

        JSONParser jp = new JSONParser();
        Set<Integer> unresolvedIssues = new HashSet();
        try{
            Object obj = jp.parse(new FileReader("./transactions.json"));
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray jsonArray = (JSONArray) jsonObject.get("issueSolved");
            for(int i=0;i<jsonArray.size();i++){
                if(jsonArray.get(i).toString() == "false")
                {
                    unresolvedIssues.add((Integer) jsonArray.get(i));
                }
            }
        }catch (Exception ex){
            ex.getMessage();
        }
        return unresolvedIssues;
    }

    /**
     * Returns a list of all solved issue messages
     */


    public List<String> getAllSolvedIssueMessages() {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the 3 transactions with the highest amount sorted by amount descending
     */
    public List<Transaction> getTop3TransactionsByAmount() {
        throw new UnsupportedOperationException();
    }

    /**
     * Returns the senderFullName of the sender with the most total sent amount
     */
    public Optional<String> getTopSender() {
        throw new UnsupportedOperationException();
    }

}
