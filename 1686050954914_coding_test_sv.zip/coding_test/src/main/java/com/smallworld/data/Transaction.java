package com.smallworld.data;

import com.smallworld.TransactionDataFetcher;

import java.util.Set;

public class Transaction {
// Represent your transaction data here.
    TransactionDataFetcher tdf = new TransactionDataFetcher();
    Double tta =  tdf.getTotalTransactionAmount();
    Double mta = tdf.getMaxTransactionAmount();
    Long cuc =  tdf.countUniqueClients();
    Set<Integer> usi = tdf.getUnsolvedIssueIds();

}
